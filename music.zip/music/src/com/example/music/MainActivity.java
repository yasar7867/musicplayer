package com.example.music;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnCompletionListener,OnSeekBarChangeListener {
	HashMap<String,String>song;
	ArrayList<HashMap<String,String>>SongList;
	ListView l;
	MediaPlayer mp=new MediaPlayer();
	ImageButton b,bs,bp,bplay,br,pn,plp,sh,re;
	int i;
	private Handler mHandler = new Handler();
	long bint=5000;
	boolean play1=false;
	boolean play11=false;
	int position=0,siz=1,poss=0;
	Intent ii;
	String pp="/storage/sdcard0/tha.mp3",title="yasar's player";
	SeekBar sk;
	byte[] data;
	boolean isShuffle=false;
	boolean isRepeat=false;
	ImageView ve;
	TextView st;
	MediaMetadataRetriever mmr;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		b=(ImageButton)findViewById(R.id.btnPlay);
		bs=(ImageButton)findViewById(R.id.btnForward);
		br=(ImageButton)findViewById(R.id.btnBackward);
		pn=(ImageButton)findViewById(R.id.btnNext);
		sh=(ImageButton)findViewById(R.id.btnShuffle);
		re=(ImageButton)findViewById(R.id.btnRepeat);
		plp=(ImageButton)findViewById(R.id.btnPrevious);
		bplay=(ImageButton)findViewById(R.id.btnPlaylist);
		ve=(ImageView)findViewById(R.id.songThumbnail);
		st=(TextView)findViewById(R.id.songTitle);
			sk=(SeekBar)findViewById(R.id.songProgressBar);
		SongList=new ArrayList<HashMap<String,String>>();
		mmr= new MediaMetadataRetriever();
		song=new HashMap<String,String>();
		SongList=new GetSong().getPlayList();
		pp=SongList.get(0).get("songPath"+0);
		title=SongList.get(0).get("songTitle"+0);
		//play();
		mp.setOnCompletionListener(this);
		sk.setOnSeekBarChangeListener(this);
		re.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				if(isRepeat)
				{
					isRepeat=false;
					re.setImageResource(R.drawable.btn_repeat);
				}
				else
				{
					isRepeat=true;
					re.setImageResource(R.drawable.btn_repeat_focused);
				}
				
			}
			
		});
		sh.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				if(isShuffle)
				{
					isShuffle=false;
					sh.setImageResource(R.drawable.btn_shuffle);
				}
				else
				{
					isShuffle=true;
					sh.setImageResource(R.drawable.btn_shuffle_focused);
					isRepeat=false;
					re.setImageResource(R.drawable.btn_repeat);
					}
				
			}
			
		});
		bs.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				
					i=mp.getCurrentPosition();
					if(i+10000<mp.getDuration())
					mp.seekTo(i+10000);
					else
						mp.seekTo(mp.getDuration());
				
			}
			
		});
		pn.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				if(isShuffle)
				{
					Random rand = new Random();
					position= rand.nextInt((SongList.size() - 1) - 0 + 1) + 0;
					pp=SongList.get(position).get("songPath"+position);
					title=SongList.get(position).get("songTitle"+position);
					play();
				}
				else
				{
				position+=1;
				if(position <= (SongList.size()- 1)){
					pp=SongList.get(position).get("songPath"+position);
					title=SongList.get(position).get("songTitle"+position);
					play();
				}else{
					position-=1;
					play();
				}	
				}
		}});		
		plp.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				if(isShuffle)
				{
					Random rand = new Random();
					position= rand.nextInt((SongList.size() - 1) - 0 + 1) + 0;
					pp=SongList.get(position).get("songPath"+position);
					title=SongList.get(position).get("songTitle"+position);
					play();
				}
				else
				{
				position-=1;
				if(position >=0){
					pp=SongList.get(position).get("songPath"+position);
					title=SongList.get(position).get("songTitle"+position);
					play();
				}else{
					position+=1;
					play();
					
				}
				}
			}
			
		});
		br.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				if(play1==true)
				{
					i=mp.getCurrentPosition();
					if(i-10000>0)
					mp.seekTo(i-10000);
					else
						mp.seekTo(0);
				}
			}
			
		});
		b.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				if(mp.isPlaying()){
					if(mp!=null){
						mp.pause();
						b.setImageResource(R.drawable.btn_play);
					}
				}else{
					if(mp!=null){
						mp.start();
						b.setImageResource(R.drawable.btn_pause);
					}
				}
				
			
			}});
		bplay.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0) {
				Intent i=new Intent(MainActivity.this,listsong.class);
				startActivityForResult(i,100);
				}
			});
	}
	public void play()
	{
	

		try
			{
				mp.reset();
				poss=0;
				mp.setDataSource(pp);
				mp.prepare();
			st.setText(title);
			mmr.setDataSource(pp);
			data = mmr.getEmbeddedPicture();
			if(data!=null)
			{
				Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
				ve.setImageBitmap(bitmap);
				data=null;
			}
			else
			{
				ve.setImageResource(R.drawable.adele);
			}
			mp.start();
		sk.setProgress(0);
		sk.setMax(100);
		
		b.setImageResource(R.drawable.btn_pause);
		updateProgressBar();
    			
	}
	 catch (SecurityException e) {
		Toast.makeText(getApplicationContext(),e.toString(), 2000).show();
	} catch (IOException e) {
		Toast.makeText(getApplicationContext(),e.toString(), 2000).show();
	}catch (IllegalArgumentException e) {
		Toast.makeText(getApplicationContext(),e.toString(), 2000).show();

	} 
	catch (IllegalStateException e){
		Toast.makeText(getApplicationContext(),e.toString(), 2000).show();
	} 
			
}
	public void pause()
	{
		play1=false;
		try
		{   
			
			
			
		mp.pause();
		b.setImageResource(R.drawable.btn_play);
    			
	}
		 catch (SecurityException e) {
				Toast.makeText(getApplicationContext(),e.toString(), 2000).show();
			} catch (IllegalArgumentException e) {
		Toast.makeText(getApplicationContext(),e.toString(), 2000).show();

	} 
	catch (IllegalStateException e){
		Toast.makeText(getApplicationContext(),e.toString(), 2000).show();
	} 
}	
	 
	private Runnable mUpdateTimeTask = new Runnable() {
		   public void run() {

			   Double percentage = (double) 0;
			   long totalDuration = mp.getDuration();
			   long currentDuration = mp.getCurrentPosition();
				long currentSeconds = (int) (currentDuration / 1000);
				long totalSeconds = (int) (totalDuration / 1000);
				percentage =(((double)currentSeconds)/totalSeconds)*100;
				int progress=percentage.intValue();
			   sk.setProgress(progress);
		       mHandler.postDelayed(this, 100);
		   }
		};
		public void updateProgressBar() {
	        mHandler.postDelayed(mUpdateTimeTask, 100);        
	    }
		@Override
	    protected void onActivityResult(int requestCode,
	                                     int resultCode, Intent data) {
	        super.onActivityResult(requestCode, resultCode, data);
	       
	        if(resultCode == 100){
	         	 pp = data.getExtras().getString("path");
	         	 title=data.getExtras().getString("title");
	         	 position=data.getExtras().getInt("pos",0);
	         	// mp.release();
	             play();
	        }
	        
	 
	    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Inflate the menu; this adds items to the action bar if it is present.
		switch(item.getItemId())
		{
		case R.id.item1:
			
			return true;
		default:
			return onOptionsItemSelected(item);
		}
	}
	@Override
	 public void onDestroy(){
	 super.onDestroy();
	    mp.release();
}
	@Override
	public void onCompletion(MediaPlayer mp) {
		
		if(isRepeat){
			play();
		} else if(isShuffle){
		
			Random rand = new Random();
			position= rand.nextInt((SongList.size() - 1) - 0 + 1) + 0;
			pp=SongList.get(position).get("songPath"+position);
			title=SongList.get(position).get("songTitle"+position);
			play();
			
		} else{
			position+=1;
			if(position < (SongList.size()- 1)){
				pp=SongList.get(position).get("songPath"+position);
				title=SongList.get(position).get("songTitle"+position);
				play();
			}else{
				play();
				
			}
		}}
	@Override
	public void onProgressChanged(SeekBar seekBar, int progress,
			boolean fromUser) {
		
	}
	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		mHandler.removeCallbacks(mUpdateTimeTask);

	}
	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		mHandler.removeCallbacks(mUpdateTimeTask);
		int totalDuration = mp.getDuration();
		int currentDuration = 0;
		totalDuration = (int) (totalDuration / 1000);
		currentDuration = (int) ((((double)seekBar.getProgress()) / 100) * totalDuration);
		int currentPosition =currentDuration*1000;
		mp.seekTo(currentPosition);
		updateProgressBar();
		}
	
}