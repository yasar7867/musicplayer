package com.example.music;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;
import android.media.MediaMetadataRetriever;


public class GetSong {
	// SDCard Path
	final String MEDIA_PATH = new String("/storage/sdcard0/");
	ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();
	HashMap<String, String> song = new HashMap<String, String>();
	File home = new File(MEDIA_PATH);
	File home1;
	MediaMetadataRetriever mmr;
	int y=0;

	// Constructor
	public GetSong(){
		
	}
	
	/**
	 * Function to read all mp3 files from sdcard
	 * and store the details in ArrayList
	 * */
	public ArrayList<HashMap<String, String>> getPlayList(){
		mmr = new MediaMetadataRetriever();
		for(File files:home.listFiles())
		{
		if(files.isDirectory())
		{
			home1=new File(files.getPath());
			aDD();
			
		}
		else if(files.isFile())
		{
			if((files.getName().endsWith(".mp3") || files.getName().endsWith(".MP3")))
			{
			song.put("songTitle"+y, (y+1)+"."+files.getName().substring(0, (files.getName().length() - 4)));
			song.put("songPath"+y, files.getPath());
			mmr.setDataSource(files.getPath());
			song.put("album"+y, mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
			song.put("artist"+y, mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
			song.put("genre"+y, mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));
			songsList.add(song);
			y++;
			}
		}
			//aDD();
		}
		y=0;
		// return songs list array
		return songsList;
	}
	public void aDD()
	{
		if (home1.listFiles(new FileExtensionFilter()).length > 0) {
			for (File file : home1.listFiles(new FileExtensionFilter())) {
				song.put("songTitle"+y, (y+1)+"."+file.getName().substring(0, (file.getName().length() - 4)));
				song.put("songPath"+y, file.getPath());
				mmr.setDataSource(file.getPath());
				song.put("album"+y, mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
				song.put("artist"+y, mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
				song.put("genre"+y, mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));
				songsList.add(song);
				y++;
			}
		}
	}
	
	class FileExtensionFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.endsWith(".mp3") || name.endsWith(".MP3"));
		}
	}
}
