package com.example.music;

import java.util.ArrayList;
import java.util.HashMap;
import android.app.Activity;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
public class listsong extends Activity{
	ArrayAdapter<String> ad;
	ListView v;
	ArrayList<HashMap<String, String>> songsListData;
	ArrayList<HashMap<String, String>> songsList;
	//String ss[]={"yyasars","music","player"};
	boolean b=false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listit);
		v=(ListView)findViewById(R.id.listView1);
		songsListData = new ArrayList<HashMap<String, String>>();
		songsList = new ArrayList<HashMap<String, String>>();
		GetSong g=new GetSong();
		songsList=g.getPlayList();
		ArrayList<String> s=new ArrayList<String>();
		int i;
		for (i = 0; i < songsList.size(); i++){
			HashMap<String, String> song = songsList.get(i);
			s.add(songsList.get(i).get("songTitle"+i).toString());
			songsListData.add(song);
		}
		
		
		ad=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,s);
        v.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        ad.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                v.setSelection(0);
            }
        });
		v.setAdapter(ad);
		v.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				int songIndex = position;
				//Intent in=new Intent();
				Intent in = new Intent(getApplicationContext(),MainActivity.class);
				in.putExtra("pos", songIndex);
				in.putExtra("title", songsListData.get(songIndex).get("songTitle"+songIndex));
				in.putExtra("path",songsListData.get(songIndex).get("songPath"+songIndex));
				setResult(100,in);
				finish();
	}

		});	
	
	}
}
